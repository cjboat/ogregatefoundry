# Chapter 1 Implementation Notes

Source: `Wandering_Heroes_of_Ogre_Gate.pdf`, Chapter 1.

## Implemented

- Character creation tab with race, subgroup, optional race approval, Scholar Option, two primary skill groups, Iron Heroes option, and manual bonus skill points.
- Skill group budgets:
  - Standard characters: two primary groups at 12 points each; remaining groups at 6 points each.
  - Scholar Option: Knowledge at 24 points; all other groups at 6 points each.
  - Defenses are included as a creation budget group.
- Cumulative rank cost calculation for skills and defenses.
- Expertise cost tracking via non-empty Expertise fields on skills or defenses.
- Flaw item skill-point values can cover overages, with a manual bonus field for table-specific cases.
- Martial discipline rank total check.
- Starting kung fu technique count check.
- Starting combat perk count check.
- Starting Qi and Qi-granted defense dot check.
- Starting spade coin check.
- Iron Heroes wound scaling.
- Optional race approval warning.
- Optional race creation cost support:
  - Kithiri free Empathy, Reasoning, and Wits ranks, plus half-cost Knowledge skills.
  - Juren free Muscle rank, doubled Wits cost, and Wits cap warning.
- Apply Creation Defaults button:
  - Raises starting Qi to 1 if needed.
  - Sets starting spade coins to 2,000 if needed.
  - Applies race free-rank minimums for Kithiri and Juren.
- Race roll modifiers are applied in roll workflows:
  - Hechi Endurance bonus, Athletics/Speed penalties, and Combat Skill penalty.
  - Juren Speed/Mental Skill penalties and melee damage bonus.
  - Ouyan Physical Skill penalty.
  - Kithiri social penalty toggle for Command, Deception, and Persuade against non-Kithiri.
- Creation summary chat card.
- Primary group panel clarifies that primary choices alter point budgets rather than adding automatic ranks.
- Expertise entry fields on skills and defenses, tracked for approval warnings but not charged against skill point budgets.
- Chapter 1 expertise metadata for standard skill expertise options.
- Sheet-level Expertise roll toggle applies the relevant +1d10 when the entered Expertise is situationally appropriate.
- Flaw item fields for creation timing, creation-limit exemption, point value, Resolve-test flag, and penalty notes.
- Creation flaw limit check, with Fated-style exemption support.
- Combat Perk item type with group, skill, bonus, XP cost, and damage-effect fields.

## Represented But Not Fully Automated Yet

- Juren extra-arm action economy needs the combat workflow from Chapter 2.
- Kithiri Multi-Ego needs a stress/check workflow.
- Ouyan Third Eye and Hechi Horn of Truth need narrative/GM-facing roll helpers.
- Sect-specific starting technique availability needs Chapter 3 and Chapter 6 compendium data.
- Starting equipment needs the Chapter 5 equipment compendiums.
- Expertise applicability is player/GM-confirmed with a roll toggle; the system does not yet infer circumstances automatically.
- Flaw penalties and combat perk effects are structured but not yet applied automatically; those depend on Chapter 2 combat/action workflow support.
