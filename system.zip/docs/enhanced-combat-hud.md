# Enhanced Combat HUD / Argon Integration Notes

The current public Argon documentation describes Enhanced Combat HUD as an "Any System" module, but system support is provided through system-specific adapter modules.

For Ogre Gate, the expected adapter identity should be:

- Module id: `enhancedcombathud-ogregatefoundry`
- Module title: `Argon - Combat HUD (OGREGATEFOUNDRY)`

First-pass Ogre Gate panels should expose:

- Weapon sets from equipped Weapon items, using Attack and Damage sheet actions.
- Kung Fu Techniques from owned Technique items, with normal, counter, and Cathartic actions.
- Defenses and Skills from owned Skill items and actor defenses.
- Movement from derived land, swim, and climb movement.
- Quick condition/status access for wounds, dying, imbalance, active afflictions, and active substances.

Compatibility caution: the public Argon wiki currently lists Version V14 / FVTT V14. This Foundry system targets v13, so the adapter should be tested against a v13-compatible Argon release before it is recommended in the manifest.
